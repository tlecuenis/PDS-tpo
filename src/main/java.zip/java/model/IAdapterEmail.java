package model;

public interface IAdapterEmail {
    void enviarNotificacion(Notificacion notificacion);
}

