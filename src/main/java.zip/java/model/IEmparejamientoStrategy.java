package model;

import java.util.List;

public interface IEmparejamientoStrategy {
    void emparejar(List<Equipo> equipos, Partido partido);
}
