package model;

import java.util.List;

public interface IEstrategiaNotificacion {
    List<Usuario> notificarDestinatarios();
}
