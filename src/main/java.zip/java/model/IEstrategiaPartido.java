package model;

public interface IEstrategiaPartido {
    void emparejar();
}
