package repository;

import model.Partido;

public interface PartidoDAO extends DAO<Partido> {
    void pendientehaceresto();
}
