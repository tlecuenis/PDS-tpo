package controller;

import model.IEmparejamientoStrategy;
import DTO.PartidoDTO;

public class PartidoController {
	
	public void crearPartido(PartidoDTO partido) {
		
	}
	
	public void buscarPartido(PartidoDTO partido) {
		
	}
	
	public void confirmar() {
		
	}
	
	public void cancelar() {
		
	}
	
	public void finalizar() {
		
	}
	
	public void iniciar() {
		
	}
	
	public void elegirEstrategia(IEmparejamientoStrategy estrategia) {
		
	}
	
}
