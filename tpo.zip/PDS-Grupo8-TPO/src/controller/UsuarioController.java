package controller;

import model.Usuario;

public class UsuarioController {
	
	private Usuario usuario;
	
	public void registrarUsuario() {
		
	}
	
	public void loginUsuario() {
		
	}
}
