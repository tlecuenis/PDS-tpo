package model;

public class Barrio {
	private String ciudad;
	
}
