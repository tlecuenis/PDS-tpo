package model;

public class Deporte {
	private String nombre;
	private Nivel nivelJuego;
	
	
}
