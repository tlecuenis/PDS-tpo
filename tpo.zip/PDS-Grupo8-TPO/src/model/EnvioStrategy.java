package model;

public interface EnvioStrategy {
    void enviarNotificacion(Notificacion notificacion);
}

