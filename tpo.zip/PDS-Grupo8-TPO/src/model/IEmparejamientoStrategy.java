package model;

import java.util.List;

public interface IEmparejamientoStrategy {
    List<Equipo> emparejar(List<Equipo> equipos);
}
