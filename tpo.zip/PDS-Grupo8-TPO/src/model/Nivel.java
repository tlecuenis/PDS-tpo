package model;

public enum Nivel {
    PRINCIPIANTE,
    INTERMEDIO,
    AVANZADO
}
